---
name: disenar-templates-figma
description: Diseña de cero una pieza nueva de Instagram en Figma -- carrusel, historia o posteo -- a partir de un Google Doc de planificacion: lee el copy, baja los visuales del doc, los mete en orden y sin recortar en frames nuevos, y arma las placas tomando como plantilla un diseño que ya exista en el archivo de esa cuenta. Usala siempre que llegue contenido nuevo para diseñar: "te paso el copy del carrusel del 18", "diseñame estas historias", "aca esta el texto, armalo con el estilo del carrusel anterior", "hace las placas de esta campaña" -- y tambien cuando piden solo los visuales: "bajame los visuales del 3/9", "necesito las placas del carrusel del viernes", "pasa estas fotos a Figma", "subi estos visuales al figma". Vale aunque no nombren Google Doc ni Figma, no digan de que pieza copiar el estilo, o den por sentada la cuenta porque vienen trabajando en eso. Escribe en Figma **unicamente con figwright**. Si de esa pieza ya hay placas hechas y solo faltan las que quedan, la que corresponde es `terminar-disenos-figma`; esta es para cuando no hay nada armado todavia.
---

# Diseñar una pieza nueva desde el doc

Llega contenido nuevo en el doc de planificacion y no hay nada armado. El
trabajo va de punta a punta: leer el copy, bajar los visuales, meterlos en
frames nuevos en Figma y diseñar las placas **con el sistema visual que la
cuenta ya tiene**, tomando de plantilla un carrusel o una historia que ya este
en el archivo.

La tentacion es diseñar. El encargo es **replicar y adaptar**: la cuenta ya tiene
un lenguaje y cada pieza que se aparta lo desgasta. Lo unico que se decide de
nuevo es como entran este copy y estas fotos en esa estructura.

**Las fotos no se recortan antes de subirlas.** Se baja el original y entra
entero al frame: el frame recorta lo que sobra y la foto queda re-encuadrable
arrastrandola. Un recorte hecho antes se decide a ciegas, recomprime la imagen
y despues hay que rehacerlo igual.

Y hay una parte que no es opcional: **cada correccion visual que te haga vuelve
a la memoria de la cuenta**. Si no, la proxima corrida copia la plantilla vieja
y reintroduce el error que ya te habian corregido. El paso 7 es tan parte del
trabajo como el diseño.

Los scripts estan en `~/.claude/skills/disenar-templates-figma/scripts/`. Los de
Python solo necesitan Python 3 (`hoja.py` ademas Pillow); `importar_imagen.mjs`
corre con el mismo Node que usa figwright.

**Si piden solo un tramo**, entra por ese paso y no rehagas los anteriores:

| Piden | Pasos |
|---|---|
| Solo bajar los visuales | 1 y 2 |
| Solo los visuales en Figma ("subi estos visuales") | 0, 1, 2 y la parte de fotos del 5; los frames quedan solo con la foto |
| Fotos que ya estan en el disco, a Figma | 0 y la parte de fotos del 5 |
| La pieza entera | Todo |

## Paso 0 -- Figwright, si o si

Se escribe con **figwright**, no con el MCP oficial (en el plan Starter se queda
sin cuota antes de terminar una corrida).

| `ping` devuelve | Que hacer |
|---|---|
| `connectedCount: 1` | Segui |
| `connectedCount: 0` | El plugin no esta abierto: Figma Desktop -> Plugins -> Development -> Figwright |
| La herramienta no existe | No esta instalado: instalalo vos, pasos en `~/.claude/skills/terminar-disenos-figma/references/figwright.md` |

Sin plugin conectado toda herramienta de diseño devuelve `plugin request
timeout` sin decir por que. Descartalo primero.

## Paso 1 -- La cuenta, su memoria y lo que falte

Antes de mirar el archivo, **lee la memoria de la cuenta**
(`~/.claude/projects/<carpeta-de-la-cuenta>/memory/`). Ahi estan el fileKey, el
doc, la carpeta local, el sistema de placas, las reservas de espacio y -- lo mas
importante -- **las correcciones que ya te hicieron**.

Si la cuenta no tiene memoria, creala ahora y no al final: la forma esta en
[references/correcciones.md](references/correcciones.md).

Y no leas solo las reglas: **lee el archivo de gusto de diseño de la cuenta**
(en Dra. Roxana Heluane, `gusto-de-diseno-rossana`; en Rio de Arena, el manual
de marca). Ahi esta lo que ninguna regla suelta dice -- que pares de color
chocan, cuanto miden los contenedores y sus margenes, hasta donde se baja el
cuerpo del texto antes de ensanchar una caja, donde se apoya el icono -- y es lo
que separa una placa que entra en el sistema de una que cumple todo y **igual
canta**.

Para arrancar hacen falta tres datos. Casi siempre estan en el pedido o en la
memoria; **pregunta solo lo que no este**, todo junto en un mensaje:

1. **El link del doc.**
2. **Que dia o que contenido** del doc, porque el doc suele tener el mes entero.
3. **La carpeta local** donde van los visuales. Si el proyecto tiene una
   convencion evidente -- `HISTORIAS/SEPTIEMBRE/08`, por ejemplo -- propone la
   ruta concreta en vez de preguntar en abstracto.

La medida de los frames y el archivo de Figma no se preguntan: salen de la
memoria y del archivo.

## Paso 2 -- El doc: copy, visuales y rol de cada placa

```bash
python3 ~/.claude/skills/disenar-templates-figma/scripts/doc_visuales.py "<url>" --fecha 18/9 --json <scratchpad>/placas.json
```

Sin `--fecha` lista todos los contenidos del doc con sus fechas, util cuando no
esta claro cual es el que piden. El script exporta el doc como HTML (no necesita
login si esta compartido por link) y saca, de cada placa, su texto y su visual,
conservando los hipervinculos: muchos visuales estan puestos como link sobre un
texto.

**Verificalo contra `--crudo` antes de escribir una letra.** Estos docs los
escriben personas y el formato varia: el parser aplana renglones y a veces
pierde placas enteras. Conta las placas: una historia con una sola placa o un
carrusel con dos casi siempre es una pieza que usa otra palabra para separar sus
partes. Es la falla mas cara porque no se ve. Si el numero no cierra, `--crudo`,
leerlo a mano y armar el JSON con el mismo formato.

**Fijate tambien que sea una placa por visual.** A veces varias imagenes son
material de una sola placa -- un collage, un antes y despues -- y ahi va un frame
por placa publicada, no uno por imagen. Sale del texto del doc, no de contar
links.

### Bajar los visuales

```bash
python3 ~/.claude/skills/disenar-templates-figma/scripts/bajar.py --json <scratchpad>/placas.json --destino "<carpeta>"
```

Guarda `placa1.jpg`, `placa2.jpg`, etc., en el orden del doc, tal cual estan.

- Si un archivo con el mismo contenido ya esta en la carpeta, lo saltea y avisa
  "ya estaba": alguien pudo haberlo bajado o retocado a mano.
- Lo que no es de Drive (Pexels, Pinterest, una carpeta) queda listado como
  pendiente con su link. Los pines se bajan con `pines.py`, y si el visual es un
  video se saca un fotograma con `fotograma.swift` (los dos en
  [references/visuales-en-figma.md](references/visuales-en-figma.md)).
- Figma solo acepta **JPG, PNG y GIF**: `sips -s format jpeg placa5.webp --out placa5.jpg`.

**Segui con el resto y avisa al final que quedo pendiente**, con el link de cada
uno. Frenar todo por un visual que falta deja el trabajo a medias.

### Mirar lo que bajo

```bash
python3 ~/.claude/skills/disenar-templates-figma/scripts/hoja.py --salida <scratchpad>/revision.jpg "<carpeta>"
```

Una fila por carpeta, miniaturas a su proporcion real y la medida de cada
original. Mandala y deci lo que no se ve mirandola: **las que van a quedar
chicas** (los pines suelen venir de 400-736 px de ancho), **las capturas de
video o con marca de agua**, **las que pierden mucho al entrar al frame** (una
panoramica en una historia 9:16 pierde dos tercios; a veces la respuesta es
cambiar la foto, y eso lo decide quien pidio el trabajo) y **las pendientes**.
Si el pedido es la pieza entera, no frenes a esperar respuesta: manda la hoja y
segui.

### El rol de cada placa

**Clasifica cada placa por su rol**, porque el rol es lo que decide la
estructura, no el orden:

| Rol | Como se reconoce | Que lleva |
|---|---|---|
| **Portada** | Es el titulo de la pieza, corto y afirmativo | Titular grande, caja chica |
| **Cuerpo** | Desarrolla, enumera, cuenta | Parrafo, enfasis al final |
| **Cierre** | Invita a hacer algo | Titular + divisor + CTA |
| **Legal** | Empieza con asterisco, dice "valido para" | Bloque chico aparte, tipografia minima |

### Los links, encuestas y stickers no se diseñan

Si el copy dice **"link a WhatsApp"**, **"link wsp"**, **"encuesta"** o
**"sticker"**, eso **no es un elemento a dibujar**: lo pega la community manager
al publicar. Lo unico que le toca al arte es **dejar el espacio libre**, una
franja continua sin texto ni logo. Los minimos cambian por cuenta y estan en su
memoria (en Rio de Arena, 230 px para link o sticker, 400 px si hay encuesta).
Si la cuenta no lo tiene anotado, preguntalo y anotalo.

## Paso 3 -- Elegir la plantilla

Este es el paso que decide como sale todo lo demas.

1. **Mismo tipo de pieza.** Historia 1080x1920, carrusel y post 1080x1440
   (desde el 18/9/2026; las piezas viejas del archivo son 1080x1350). Una
   historia no se adapta de un carrusel: cambian las proporciones y las
   reservas.
2. **La mas reciente de esa cuenta**, no la mas linda. El sistema se corrige con
   el tiempo y la ultima es la que incorpora las correcciones. Para saber cual
   es, ordena las filas del canvas por coordenada Y y mira las de mas abajo, que
   suelen ser las nuevas -- pero confirmalo, no es una ley.
3. **Contrastala con la memoria.** Si la memoria dice que algo se corrigio y la
   plantilla no lo refleja, **gana la memoria**: esa plantilla es anterior a la
   correccion. Es el error mas caro de este flujo, porque copiar se siente
   correcto.
4. **Mostrasela antes de construir.** `get_screenshot` de la plantilla candidata
   y una linea: "la armo con el estilo de esta, ¿va?". Es mucho mas barato que
   rehacer cinco placas.

Si el copy tiene un rol que la plantilla no tiene -- un cierre con legal cuando
la plantilla no lleva legal -- decilo en ese mismo mensaje y proponé de donde
sacar ese bloque.

## Paso 4 -- Leer el sistema de la plantilla

Con `get_nodes_info` sobre una placa de cada rol. Sacá:

- **Donde va el logo y donde la caja** (suelen ir en lados opuestos).
- **La caja**: `cornerRadius`, color, opacidad, padding al texto.
- **La tipografia**: familia, tamaño, `lineHeight`, y como se hace la jerarquia
  (peso, tamaño, `textCase UPPER`, italica: depende de la cuenta).
- **El color y su `boundVariables`**: si el fill esta bindeado a una variable, el
  texto nuevo tiene que quedar bindeado igual o se despega del sistema.

**Nunca midas de una captura.** `get_screenshot` sirve para verificar lo que
construiste, no para medir lo que vas a construir.

## Paso 5 -- Construir

Los detalles de frames e importacion de fotos estan en
[references/visuales-en-figma.md](references/visuales-en-figma.md): leelo antes
de crear el primer frame.

**Frames nuevos en una fila libre.** Agrupa los frames del canvas por `y`, busca
la fila mas abajo, sumale su altura y dejale el aire que ya usa el archivo.
Nunca reutilices frames existentes: si alguien empezo a diseñar ahi, su trabajo
desaparece. **Copia la convencion de nombres y el paso horizontal** de las filas
que ya estan (`P1-<Tema>`, `H1-<tema>`; el paso suele ser ancho + 94).

**Las fotos, una por frame y en el orden del doc:**

```bash
node ~/.claude/skills/disenar-templates-figma/scripts/importar_imagen.mjs --figma "<fileName>" --frame <id del frame> \
  --nombre "placa1" "<carpeta>/placa1.jpg"
```

Entra el original **entero y centrado**, escalado para cubrir el frame. No le
pases `--offset` en la primera pasada: solo despues de mirar el render, si el
sujeto quedo cortado. Por MCP `import_image` **no sirve para fotos del disco**
(solo acepta una URL `https` publica o el base64 en la llamada); el script le
habla directo al server local de figwright.

**Despues, el diseño encima. Cloná los bloques, no los crees.** `clone_node` del
grupo de la plantilla, `reparent_nodes` al frame nuevo, y recien ahi `set_text`
+ `set_text_range`. Clonar hereda alineacion, color, binding, radio y opacidad.
Y hay algo que no se recupera creando: `set_text_properties` **no tiene
`textAlignHorizontal`**, asi que un texto creado de cero queda a la izquierda y
no hay forma de centrarlo.

**Medí antes de dimensionar.** `textAutoResize=HEIGHT` (o `WIDTH_AND_HEIGHT` si
la caja tiene que abrazar un titulo corto), leer el alto real con
`get_nodes_info`, dimensionar el rectangulo con el padding del sistema, y volver
a `NONE`. Un `\n` al final crea un renglon fantasma que infla la medida: sacalo.

**Cuando el copy no llena la estructura de la plantilla**, saca el elemento que
sobra en vez de dejarlo colgando. Una portada con divisor y nada debajo se ve
rota; una portada con solo el titular se ve bien.

## Paso 6 -- Verificar

`get_screenshot` de las placas nuevas **junto a una de la plantilla**. La
pregunta no es "¿esta linda?" sino **"¿se nota cual es nueva?"**. Si canta, algo
del sistema no se copio.

Ademas, explicitamente:

- **El orden**: que la placa 1 sea la placa 1. Dos fotos cruzadas no dan error
  en ningun lado.
- **Que sujeto quedo cortado** por el centrado: se arregla arrastrando la foto
  o reimportando con `--offset`.
- **Lo que trae la foto de fabrica**: marca de agua, la `×` de Pinterest, un
  borde de captura. Eso no lo arregla ningun encuadre; hay que decirlo.
- La franja libre para el sticker, y que el logo haya quedado sobre una zona
  con contraste.

## Paso 7 -- Las correcciones, a la memoria

Cuando te devuelva cambios -- te los diga o los haga en Figma -- **no alcanza con
aplicarlos**. Hay que releer el archivo, entender que cambio exactamente y
anotarlo.

El detalle completo esta en
[references/correcciones.md](references/correcciones.md), pero lo esencial:

- **Relee el archivo, no te fies de lo que te dijo.** "Movi el logo" puede
  significar tambien que movio la caja y la achico. Compará contra lo que
  construiste.
- **Anota el criterio, no el numero.** "El logo va abajo *porque arriba se
  pierde contra el cielo*" se puede aplicar a una foto nueva; "logo en y=1130"
  no.
- **Deci a que pisa.** Si la plantilla que usaste todavia tiene la version
  vieja, la memoria tiene que decirlo con todas las letras, o la proxima corrida
  la copia de nuevo.

## Cerrar

Deci que placas quedaron, con nombre de frame, node id y la foto que lleva cada
una, y despues **las decisiones que tomaste vos**: donde pusiste el enfasis, que
tamaño le diste a un texto corto, que elemento sacaste porque el copy no lo
tenia. Es lo unico que no se puede deducir mirando el resultado, y es donde van
a estar las correcciones.

Sumá lo que quedo abierto: visuales pendientes con su link, imagenes chicas o
con marca. Y **deci que las fotos se re-encuadran arrastrandolas** dentro del
frame, sin reexportar nada: no es obvio mirando el resultado.

Los frames quedan diseñados. **Exportar y subir a Drive es otra cosa** y tiene
su propia skill (`placas-a-drive`): ofrecelo, no lo hagas de prepo.

## Cuando algo no sale

| Sintoma | Que suele ser | Que hacer |
|---|---|---|
| El doc no exporta (HTTP 403) | No esta compartido por link | Pedir que lo compartan, o que peguen el texto |
| El parser no encuentra las placas | El doc usa otro formato | `--crudo` y leerlo a mano |
| Una descarga devuelve HTML | El archivo de Drive no es publico | Listarlo como pendiente con su link |
| Figma rechaza la imagen | Es `.webp` | Convertir a JPG con `sips` |
| `plugin request timeout` | El plugin no esta abierto | `ping`; pedir que lo abran |
| "Reached the Figma MCP tool call limit" | Se uso el MCP oficial | Usar figwright |
| El texto nuevo quedo a la izquierda | Se creo en vez de clonar | Clonar el bloque de la plantilla |
| La caja quedo mas alta que el texto | `\n` final o alto a ojo | Medir con `textAutoResize` |
| El color no matchea aunque el RGB sea igual | Falta el `boundVariables` | Clonar, o bindear la variable |
| Los frames nuevos aparecen encimados | Se creo en una fila ocupada | Recalcular la fila libre |
| Le corregiste algo que ya te habian corregido antes | Se copio la plantilla sin leer la memoria | Paso 1 y paso 3.3 |

Los errores propios del script de importacion estan en
[references/visuales-en-figma.md](references/visuales-en-figma.md).
