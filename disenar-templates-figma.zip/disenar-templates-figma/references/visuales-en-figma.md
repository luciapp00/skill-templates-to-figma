# Meter los visuales en Figma

## Con que herramienta

Se escribe con **figwright** (MCP local + plugin dentro de Figma), no con el
MCP oficial. En el plan Starter el oficial corta con "You've reached the Figma
MCP tool call limit" a las pocas llamadas -- no alcanza ni para terminar una
corrida, y falla igual en `get_metadata` que en `use_figma`. Si algun dia el
plan cambia, el flujo oficial esta al final de este archivo.

Empeza siempre por `ping`. Si devuelve `"connectedCount": 0` el plugin no esta
abierto y **ninguna** herramienta de diseño va a responder: se cuelgan con
`plugin request timeout`, que no dice nada sobre la causa real. Pedile que abra
Figma Desktop -> Plugins -> Development -> Figwright. Despues, `get_metadata`:
su `fileName` confirma que el plugin esta en el archivo correcto, y es el valor
que va en el `--figma` del script del paso 3.

El `fileKey` sale de la URL: `figma.com/design/<fileKey>/<nombre>?node-id=...`

## 1. Mirar el archivo antes de crear

```
search_nodes  name="-"  type="FRAME"
```

Casi todos los frames de pieza tienen guion en el nombre (`P1-ElBañado`,
`H2-InhalarPausa-1`), asi que esa busqueda devuelve el mapa de placas del
archivo con nombre, `x`, `y` y medidas, sin traerte los cientos de nodos
internos. De ahi salen las tres cosas que necesitas:

**Convencion de nombres.** Copiala, no inventes otra. En estos archivos es
`P<n>-<TemaEnCamelCase>` para carrusel y `H<n>-<tema>` para historias. El tema
sale del titulo del contenido en el doc. Si dos piezas del mes comparten tema,
desempata en el tema (`H1-BiesTip` cuando ya existe un `H1-Bies`), no agregando
un numero al final.

**La medida.** Mirala en las piezas del mismo tipo, **de las mas nuevas**: los
archivos arrastran placas viejas de cuando la medida era otra, y copiar el alto
de una de esas mete la pieza nueva en un formato discontinuado. Ante la duda,
historia 1080x1920 y carrusel o post 1080x1440, y decilo al cerrar.

**Paso horizontal.** Resta la `x` de dos frames consecutivos de una misma fila.
Suele haber una fila desprolija donde alguien movio algo a mano: usa el paso
que mas se repite, no el de esa. Si no hay con que comparar, ancho + 94.

**Fila libre.** Agrupa por `y`, busca la fila mas abajo, sumale su altura y
dejale aire (mira los huecos que ya usa el archivo; suelen ser 280 px, no 90).
Ahi va la fila nueva. Crear en una fila vacia en vez de reutilizar frames
existentes evita pisar trabajo: si alguien ya empezo a diseñar esa pieza, su
texto y su logo siguen intactos y despues se decide a mano que se queda.

## 2. Crear los frames vacios

Un `create_frame` por placa; se pueden mandar todos en el mismo turno.

```
create_frame  name="P1-NoEsperesVacaciones"  width=1080  height=1440  x=2528  y=16331
```

Devuelve el `nodeId` de cada uno. Guardalos: el paso siguiente los necesita.

## 3. Meter las imagenes

Con `scripts/importar_imagen.mjs`, una corrida por placa:

```bash
node ~/.claude/skills/disenar-templates-figma/scripts/importar_imagen.mjs --figma "<fileName>" --frame <id del frame> \
  --nombre "placa1" "<carpeta>/placa1.jpg"
```

Va el **original** de `bajar.py`, entero y sin recortar. El script mete la foto,
la escala para que cubra el frame y la centra: el frame recorta solo lo que
sobra, porque tiene `clipsContent`. Devuelve el `nodeId` de la foto y la
geometria con que quedo.

`--offset` (0 = pegada a la izquierda o arriba, 0.5 = centro, 1 = a la derecha o
abajo) corre la foto en el eje que sobra. **En la primera pasada no se usa**: el
default 0.5 es el que va. Sirve despues, si miraste el render y el sujeto quedo
cortado, y solo para esa placa. Cuando lo uses, dejalo en el nombre de la capa
(`placa1 (off 0.4)`) para que quede rastro de como se decidio el encuadre.

`--figma` es el `fileName` que devolvio `get_metadata`, y es obligatorio: con
el plugin abierto en dos archivos, figwright escribe en el ultimo que se toco.
Si el nombre no coincide, el script aborta antes de escribir, en vez de meter
la foto en el archivo de otro cliente.

### Por que un script y no `import_image`

Por MCP, `import_image` toma `url` o `data` (base64), y para una foto del disco
no sirve ninguna de las dos:

- **`data`**: un JPG de placa son ~1 MB, o sea ~1,3 MB de base64 que habria que
  transcribir caracter por caracter en la llamada. Es inviable.
- **`url`**: tiene que ser `https` y publica. Figma bloquea `http://` desde el
  plugin, asi que un server local no sirve (declarar `http://localhost` en el
  manifest tampoco, probado). Y un Drive sin compartir por link devuelve la
  pagina de login en vez de la imagen.

El server de figwright escucha en `127.0.0.1:3055/rpc` (msgpack) y le pasa esas
llamadas al plugin. El script lee el archivo, arma el base64 y llama ahi
directo, asi que la foto nunca pasa por la conversacion. No depende de como
esten compartidos los archivos ni de ningun CDN.

Sale mejor que subir un JPG ya recortado: entra el original sin recomprimir, y
queda **re-encuadrable arrastrando el rectangulo** dentro del frame, sin volver
a exportar nada. Por eso el recorte no se hace antes: se decide aca, con el
diseño a la vista, y cambiarlo no cuesta nada. Deci esto al cerrar, porque no
es obvio mirando el resultado.

Tres detalles que conviene anticipar:

- **Figma no acepta mas de 4096 px por lado** (`Image is too large`). El script
  lo detecta y manda una copia achicada con `sips`, que conserva la proporcion:
  el encuadre no cambia.
- **Solo entran JPG, PNG y GIF.** Un `.webp` lo rechaza; convertilo antes con
  `sips -s format jpeg placa5.webp --out placa5.jpg`.
- La imagen queda como **rectangulo hijo**, no como relleno del frame. Los
  frames viejos del archivo tienen la foto como fill (los hizo el MCP oficial);
  la diferencia no molesta para diseñar encima y hace mas facil reencuadrar,
  pero mencionala en vez de dejar que la descubra.

**Para reemplazar una foto** que ya esta en un frame (la version limpia de un
preview con marca de agua, por ejemplo): importar la nueva con el script en el
mismo frame, verificarla, y recien despues borrar la vieja con `delete_nodes`.
El `nodeId` de la foto cambia.

**Si cambia la medida del frame** despues de haber metido la foto, no alcanza
con `resize_nodes`: la foto queda con la escala y la posicion viejas. Borrala
con `delete_nodes` y volve a importarla, que recalcula el encuadre sobre la
medida nueva.

## 4. Verificar

```
save_screenshots  nodeIds=[...]  outDir=<scratchpad>  format=JPG  scale=0.25
```

Exporta los **frames**, no las fotos: asi ves el recorte real, que es lo que se
publica. A escala 0.25 alcanza de sobra para revisar y no infla la conversacion.

Juntalas en una sola hoja y miralas. Tres cosas que se ven ahi y en ningun otro
lado:

- **El orden.** Que placa 1 sea la placa 1. Un frame salteado o dos fotos
  cruzadas no dan error en ningun lado.
- **Que sujeto quedo cortado.** El centrado acierta seguido pero no siempre.
  El que no cierre se arregla arrastrando la foto en Figma, o reimportandola
  con `--offset`.
- **Lo que trae la foto de fabrica**: marca de agua, la `×` de la app de
  Pinterest quemada en una esquina, un borde de captura de pantalla. Eso no lo
  arregla ningun encuadre; hay que decirlo.

Y compara la geometria que devolvio el script contra la medida del frame: si el
`width`/`height` de la foto es menor que el del frame, quedo un borde vacio y
algo salio mal en la importacion.

## Errores que aparecen seguido

| Sintoma | Causa | Salida |
|---|---|---|
| `plugin request timeout` en todo | El plugin no esta abierto | `ping`; pedir que lo abran |
| `fetch failed` al correr el script | El server de figwright no esta levantado (el MCP no cargo en esta sesion) | `ping`; si no responde, reiniciar la sesion |
| `El plugin esta en "X", no en "Y"` | El plugin esta abierto en otro archivo | Pedir que lo cierren ahi y volver a correr |
| `No encuentro @msgpack/msgpack` | Figwright nunca corrio con `npx` en esta maquina | Instalarlo y arrancarlo una vez |
| `...quedo como <id>, sin encuadrar` | El script corto despues de importar | Borrar ese nodo y volver a correr |
| Los frames nuevos aparecen encimados | Se creo en una fila ocupada | Releer con `search_nodes` y recalcular |
| Limite de llamadas del MCP oficial | Plan Starter | Usar figwright |

## Si algun dia hay plan con cuota

Con el MCP oficial hay otra via para el paso 3: `upload_assets` sube el archivo
local y lo deja como relleno del frame:

```
upload_assets  fileKey=<key>  count=5  nodeIds=[...]  scaleMode=FILL
curl -s -X POST "<submitUrl>" -F "file=@<ruta>;type=image/jpeg;filename=<nombre>"
```

Cada URL se usa una sola vez y vence a los 10 minutos. `scaleMode=FILL` hace lo
mismo que el script -- cubre el frame y centra -- pero la foto queda como
relleno, no como rectangulo hijo, y reencuadrarla despues es mas incomodo.
Antes de llamar `use_figma`
hay que cargar su guia (`get_figma_skill uri="skill://figma/figma-use/SKILL.md"`)
y pasar `skillNames="resource:figma-use"`.

## Si hay que recortar el fondo

```bash
swift ~/.claude/skills/disenar-templates-figma/scripts/recortar.swift placa1.jpg crudo.png
python3 ~/.claude/skills/disenar-templates-figma/scripts/despintar.py crudo.png placa1-sinfondo.png 2.2
```

El primero usa Vision, el mismo motor del "Quitar fondo" de Vista Previa: local,
sin instalar modelos ni subir la foto a ningun servicio. Conserva el lienzo
original, que es lo que permite superponer el recorte **exactamente** sobre la
foto con fondo.

El segundo hace falta siempre: los pixeles del borde vienen mezclados con el
color del fondo viejo, y sobre un fondo de otro color eso se ve como un fleco
gris. El script despeja el color real y cierra el alfa con una curva (el ultimo
numero, 2.2 anduvo bien; menos deja fleco, mas empieza a comerse las ramitas).
**No erosiones el alfa**: festonea el borde y se lleva puesto todo lo fino.

## Otras herramientas de `scripts/`

- `pines.py <url> <destino.jpg>`: baja un pin de Pinterest al tamaño original
  (`bajar.py` solo baja de Drive).
- `swift fotograma.swift <video> <salida.jpg> [segundo]`: saca un fotograma
  cuando el visual del doc es un video. No hay ffmpeg en esta maquina.
- `renglones.py`: ancho real de cada renglon en Montserrat, para decidir cortes
  antes de escribir en Figma (importalo: `from renglones import ancho`).
