# La memoria de cada cuenta y el ciclo de correcciones

La memoria de Claude es **por carpeta de proyecto**: lo que se guarda trabajando
en Rio de Arena no se ve trabajando en otra cuenta. Cada cuenta tiene la suya en
`~/.claude/projects/<carpeta-de-la-cuenta>/memory/`.

Lo que vale para **todas** las cuentas esta en
`~/.claude/skills/terminar-disenos-figma/references/memorias.md`, que es el unico
lugar compartido entre clientes. Leelo tambien.

## Si la cuenta no tiene memoria todavia

Creala al empezar, no al terminar. Un archivo por hecho, con frontmatter
(`name`, `description`, `metadata.type`) y una linea de indice en `MEMORY.md`.
Los huecos que se pagan caro:

| Tema | Que anotar |
|---|---|
| **Figma** | El `fileKey`, y que es el archivo permanente de la cuenta |
| **El doc** | El link, y de donde salen los visuales |
| **Sistema de placas** | Logo, caja, tipografia, color y variable, con medidas |
| **Reservas** | Los px libres para link/sticker y para encuesta de esta cuenta |
| **Correcciones** | Cada cambio visual que te hicieron, con su criterio |
| **Mañas del archivo** | Nombres repetidos, filas duplicadas, cosas que rompen |

---

# El ciclo de correcciones

Es lo que hace que la cuenta mejore en vez de repetir los mismos errores. Tiene
cuatro partes y ninguna es opcional.

## 1. Detectar que hubo correccion

Hay dos formas y las dos cuentan:

- **Te lo dice.** "el logo va abajo", "eso ponelo en negrita".
- **Lo hace ella en Figma y despues te avisa.** "mira el archivo, hice unos
  cambios". Esta es la mas rica y la mas facil de subestimar.

Tambien cuenta cuando **rechaza** algo que propusiste. Que te digan "no, dejalo
como estaba" es informacion sobre el criterio de la cuenta.

## 2. Releer el archivo, no confiar en el resumen

**Lo que te dice es lo que noto, no necesariamente todo lo que cambio.** Ya
paso: dijo "movi el logo de arriba a abajo", y ademas de eso habia subido la
caja de texto al lugar que dejo libre el logo y la habia achicado de 983 a 749
px para que abrazara el titular. Dos de los tres cambios no estaban en el
mensaje.

Asi que releela con `get_nodes_info` / `scan_text_nodes` sobre los frames que
tocó y **compara contra lo que vos habias construido**. Anota las diferencias,
no el titular del mensaje.

Si un nodo cambio de id, probablemente lo borro y lo pego de nuevo: buscalo por
tipo o por nombre en vez de darlo por desaparecido.

## 3. Anotar el criterio, no el numero

Un numero solo sirve para repetir esa placa. Un criterio sirve para la
siguiente, que va a tener otra foto y otro copy.

- Mal: `logo en y=1130`.
- Bien: `el logo va abajo porque es blanco y arriba de estas fotos casi siempre
  hay cielo o follaje claro donde se pierde; abajo hay suelo o textil. El
  default es abajo, pero el criterio es contraste: si el borde inferior tambien
  sale lavado, elegi la zona con tono.`

Cuando el criterio no te lo den, **preguntalo**. "¿Lo moviste por contraste o
porque tapaba algo?" es una pregunta de diez segundos que cambia lo que se
puede hacer con el dato despues.

Si la correccion vale como regla general para la cuenta, decilo explicitamente;
si fue por esta foto en particular, tambien. Son cosas distintas y confundirlas
hace que se aplique donde no va.

## 4. Decir a que pisa

**Esta es la parte que se olvida y la que hace daño.** La plantilla que usaste
sigue teniendo la version vieja. Si la memoria no dice que la correccion pisa a
lo que hace esa pieza, la proxima corrida va a copiarla y reintroducir el error
-- prolijamente, siguiendo el sistema, y mal.

Escribilo con todas las letras en el archivo de memoria:

> El carrusel X es la referencia de **medidas y tipografia**, no de donde va el
> logo: ahi todavia esta arriba, y eso quedo corregido el <fecha>.

Y revisa si alguna memoria vieja quedo diciendo lo contrario. **Una memoria
desactualizada hace mas daño que una que falta, porque se le cree.** Corregi el
archivo existente en vez de agregar uno nuevo que lo contradiga.

## Cuando la correccion es de criterio, no de pixeles

A veces lo que corrige no es una medida sino como se decide. "Que la caja
abrace al texto, nunca ancho fijo" no es un numero: es una regla que cambia
todas las placas futuras. Esas van anotadas como regla, con el rango de valores
observado a modo de referencia, y marcadas como tal para que no se lean como una
medida mas.

## Que no anotar

- Lo que se puede leer del archivo de Figma en cualquier momento (medidas de una
  placa concreta, ids de nodo de una pieza vieja).
- Lo que solo valia para esa corrida.
- Preferencias que dedujiste vos sin que te las confirmaran. Si no estas seguro
  de si es regla o fue por esta vez, preguntalo antes de escribirlo como regla.
