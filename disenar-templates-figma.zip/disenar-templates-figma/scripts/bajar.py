#!/usr/bin/env python3
"""Baja a una carpeta los visuales de Drive que encontro doc_visuales.py.

Dos cosas que parecen detalles pero rompen el flujo si no se manejan:

1. Drive intercepta los archivos grandes con una pagina de "no pudimos
   analizar en busca de virus". La respuesta es HTML, no la imagen. Hay que
   releer el formulario y repetir el pedido con el token de confirmacion.
2. La carpeta destino suele tener descargas previas hechas a mano. Comparar
   por md5 evita duplicar y, mas importante, evita pisar un archivo que
   alguien ya retoco.

Uso:
  bajar.py --json placas.json --destino "ruta/carpeta"
  bajar.py --ids 1abc,2def --destino "ruta/carpeta"
"""

import argparse
import hashlib
import http.cookiejar
import json
import os
import re
import sys
import urllib.parse
import urllib.request

UC = "https://drive.google.com/uc?export=download&id={}"
EXT = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/gif": ".gif",
    "video/mp4": ".mp4",
    "application/pdf": ".pdf",
}


def opener():
    cj = http.cookiejar.CookieJar()
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [("User-Agent", "Mozilla/5.0")]
    return op


def confirmar(op, body, url):
    """Drive devolvio la pagina de confirmacion: rearmar el pedido real."""
    txt = body.decode("utf-8", "replace")
    m = re.search(r'action="([^"]+)"', txt)
    if not m:
        return None
    action = m.group(1).replace("&amp;", "&")
    campos = dict(
        re.findall(r'name="([^"]+)"\s+value="([^"]*)"', txt)
    )
    sep = "&" if "?" in action else "?"
    return op.open(action + sep + urllib.parse.urlencode(campos), timeout=120)


def bajar_uno(op, drive_id):
    r = op.open(UC.format(drive_id), timeout=120)
    body = r.read()
    ctype = r.headers.get("Content-Type", "").split(";")[0].strip()
    if ctype.startswith("text/html"):
        r2 = confirmar(op, body, r.geturl())
        if r2 is None:
            raise RuntimeError(
                "Drive devolvio HTML y no encontre el formulario de confirmacion. "
                "Puede ser que el archivo no este compartido por link."
            )
        body = r2.read()
        ctype = r2.headers.get("Content-Type", "").split(";")[0].strip()
        if ctype.startswith("text/html"):
            raise RuntimeError(
                "Drive sigue devolviendo HTML. Revisa que el archivo sea publico."
            )
    return body, ctype


def md5(b):
    return hashlib.md5(b).hexdigest()


def md5_archivo(p):
    with open(p, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", help="salida de doc_visuales.py --json")
    ap.add_argument("--ids", help="lista de drive ids separados por coma")
    ap.add_argument("--destino", required=True)
    ap.add_argument("--prefijo", default="placa")
    a = ap.parse_args()

    if a.json:
        with open(a.json, encoding="utf-8") as f:
            data = json.load(f)
        items = [p for c in data for p in c["placas"]]
    elif a.ids:
        items = [
            {"placa": i + 1, "drive_id": d.strip(), "origen": "drive", "visual": d}
            for i, d in enumerate(a.ids.split(","))
            if d.strip()
        ]
    else:
        sys.exit("Pasa --json o --ids")

    os.makedirs(a.destino, exist_ok=True)
    existentes = {}
    for n in os.listdir(a.destino):
        p = os.path.join(a.destino, n)
        if os.path.isfile(p):
            try:
                existentes[md5_archivo(p)] = n
            except OSError:
                pass

    op = opener()
    ok, ya, pendientes, fallos = [], [], [], []

    for it in items:
        n = it["placa"]
        if it.get("origen") != "drive" or not it.get("drive_id"):
            pendientes.append(it)
            continue
        try:
            body, ctype = bajar_uno(op, it["drive_id"])
        except Exception as e:
            fallos.append((n, str(e)))
            continue

        h = md5(body)
        if h in existentes:
            ya.append((n, existentes[h]))
            continue

        nombre = f"{a.prefijo}{n}{EXT.get(ctype, '.bin')}"
        with open(os.path.join(a.destino, nombre), "wb") as f:
            f.write(body)
        existentes[h] = nombre
        ok.append((n, nombre, len(body), ctype))

    for n, nombre, size, ctype in ok:
        print(f"bajado   placa {n} -> {nombre}  ({size//1024} KB, {ctype})")
    for n, nombre in ya:
        print(f"ya estaba  placa {n} -> {nombre} (mismo contenido, no la toque)")
    for n, err in fallos:
        print(f"FALLO    placa {n}: {err}")
    for it in pendientes:
        print(f"pendiente  placa {it['placa']}: no es Drive -> {it.get('visual')}")

    print(
        f"\n{len(ok)} bajadas, {len(ya)} ya estaban, "
        f"{len(fallos)} fallaron, {len(pendientes)} pendientes de conseguir aparte."
    )
    if pendientes or fallos:
        sys.exit(0)  # no es error del script: hay que avisarle a la persona


if __name__ == "__main__":
    main()
