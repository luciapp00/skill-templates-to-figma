"""Ancho real de cada renglon, medido con la Montserrat instalada.

Predice con ~1 px de error el ancho que despues reporta Figma, asi que sirve
para decidir los cortes de renglon antes de escribir, en vez de ir y volver.
Importalo:  from renglones import ancho, alto, verificar
"""
import os
from PIL import ImageFont

DIR = os.path.expanduser("~/Library/Fonts")
PESOS = {"SemiBold": ("SemiBold", 42), "Bold": ("Bold", 42),
         "ExtraBold": ("ExtraBold", 42), "ExtraBold54": ("ExtraBold", 54)}
F = {k: ImageFont.truetype(f"{DIR}/Montserrat-{a}.ttf", s) for k, (a, s) in PESOS.items()}
EMOJI = 52.0  # el emoji no esta en Montserrat: Figma lo saca de otra fuente


def ancho(linea, peso="SemiBold"):
    limpio = "".join(c for c in linea if ord(c) < 0x2000)
    e = sum(1 for c in linea if ord(c) >= 0x2000 and c != "️")
    return F[peso].getlength(limpio) + e * EMOJI


def alto(lineas, peso="SemiBold"):
    return len(lineas) * (61.90 if peso == "ExtraBold54" else 56.41)


def verificar(bloques, maximo):
    """bloques = [(nombre, peso, [renglones])]. Avisa cual se pasa del ancho util."""
    ok = True
    for n, peso, lis in bloques:
        ws = [ancho(l, peso) for l in lis]
        malo = [l for l, w in zip(lis, ws) if w > maximo]
        print(f"\n[{n}] {peso}  mancha {max(ws):.0f}/{maximo}  {len(lis)} rengl.  "
              f"alto {alto(lis, peso):.0f}" + ("   <-- SE PASA" if malo else ""))
        for l, w in zip(lis, ws):
            print(f"    {w:>6.0f} {'!' if w > maximo else ' '} {l}")
        ok = ok and not malo
    return ok


if __name__ == "__main__":
    assert ancho("iiii") < ancho("MMMM")
    assert ancho("abc", "ExtraBold54") > ancho("abc", "SemiBold")
    assert ancho("x 🍷") > ancho("x ")
    assert alto(["a", "b"]) == 2 * 56.41
    print("renglones autocheck ok")
