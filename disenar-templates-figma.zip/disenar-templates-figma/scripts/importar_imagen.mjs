#!/usr/bin/env node
// Mete una foto del disco adentro de un frame de Figma, entera: la imagen cubre
// el frame y lo que sobra se reparte segun --offset (0 = pegada a la izquierda o
// arriba, 0.5 = centro, 1 = a la derecha o abajo). El default centrado es el que
// va en la primera pasada; el frame recorta solo, y la foto queda re-encuadrable
// arrastrandola, asi que no hay que recortar nada antes de subir.
//
// Por que existe: por MCP, import_image solo sirve con una URL https publica. El
// base64 de una foto no se puede transcribir en la llamada, y Figma bloquea http y
// localhost. Este script habla directo con el server local de figwright
// (127.0.0.1:3055/rpc, en msgpack) y le pasa el archivo en base64 sin que pase
// por la conversacion. Entra el original, sin recomprimir, y queda re-encuadrable
// arrastrando el rectangulo.
//
// Uso:
//   node importar_imagen.mjs --figma "Dr.Teofilo" --frame 65:2 --nombre "placa1" placa1.jpg
//
// --figma es obligatorio: con el plugin abierto en dos archivos, figwright escribe
// en el ultimo que se toco. Si el nombre no coincide, aborta antes de escribir.
import { execFileSync } from "node:child_process";
import { existsSync, readdirSync, readFileSync, rmSync } from "node:fs";
import { homedir, tmpdir } from "node:os";
import { extname, join } from "node:path";
import { parseArgs } from "node:util";

const { values: o, positionals: [archivo] } = parseArgs({
  allowPositionals: true,
  options: {
    figma: { type: "string" },
    frame: { type: "string" },
    offset: { type: "string", default: "0.5" },
    nombre: { type: "string" },
  },
});
const off = Number(o.offset);
if (!archivo || !o.figma || !o.frame || !(off >= 0 && off <= 1)) {
  console.error('Uso: node importar_imagen.mjs --figma "<archivo de Figma>" --frame <nodeId> [--offset 0..1] [--nombre "..."] <imagen>');
  process.exit(1);
}

// msgpack viene con figwright; la carpeta de npx cambia de hash entre versiones.
const npx = join(homedir(), ".npm/_npx");
const lib = existsSync(npx) && readdirSync(npx)
  .map((d) => join(npx, d, "node_modules/@msgpack/msgpack/dist.esm/index.mjs"))
  .find(existsSync);
if (!lib) throw new Error("No encuentro @msgpack/msgpack en ~/.npm/_npx: figwright tiene que haber corrido con npx en esta maquina");
const { encode, decode } = await import(lib);

let n = 0;
const rpc = async (toolName, args) => {
  const res = await fetch("http://127.0.0.1:3055/rpc", {
    method: "POST",
    headers: { "content-type": "application/msgpack" },
    body: encode({ requestId: `importar-${process.pid}-${n++}`, toolName, args }),
  });
  const r = decode(new Uint8Array(await res.arrayBuffer()));
  if (r.kind !== "ok") throw new Error(`${toolName}: ${r.code} ${r.message}`);
  return r.result;
};

const { fileName } = await rpc("get_metadata", {});
if (fileName !== o.figma) throw new Error(`El plugin esta en "${fileName}", no en "${o.figma}": cerra Figwright en los otros archivos`);
const [frame] = (await rpc("get_nodes_info", { nodeIds: [o.frame] })).nodes;
if (!frame) throw new Error(`No existe el nodo ${o.frame} en "${fileName}"`);

// Entra a su tamaño natural, y el encuadre se calcula con la medida que lee Figma.
const importar = (ruta) =>
  rpc("import_image", { data: readFileSync(ruta).toString("base64"), parentId: o.frame, ...(o.nombre && { name: o.nombre }) });
let nodeId;
try {
  ({ nodeId } = await importar(archivo));
} catch (e) {
  // Figma no acepta mas de 4096 px por lado ("Image is too large"). Se manda una
  // copia achicada con sips (viene con macOS), que conserva la proporcion.
  if (!/too large/i.test(e.message)) throw e;
  const copia = join(tmpdir(), `importar-${process.pid}${extname(archivo)}`);
  execFileSync("sips", ["-Z", "4096", "-s", "formatOptions", "92", archivo, "--out", copia], { stdio: "ignore" });
  console.error("Pasa de 4096 px: entra una copia achicada a 4096");
  try {
    ({ nodeId } = await importar(copia));
  } finally {
    rmSync(copia, { force: true });
  }
}
try {
  const [img] = (await rpc("get_nodes_info", { nodeIds: [nodeId] })).nodes;
  const k = Math.max(frame.width / img.width, frame.height / img.height);
  const width = img.width * k, height = img.height * k;
  const x = -(width - frame.width) * off, y = -(height - frame.height) * off;
  await rpc("resize_nodes", { nodeIds: [nodeId], width, height });
  await rpc("set_position", { nodeId, x, y });
  const r2 = (v) => Math.round(v * 100) / 100;
  console.log(JSON.stringify({ nodeId, x: r2(x), y: r2(y), width: r2(width), height: r2(height) }));
} catch (e) {
  e.message += ` (la foto quedo como ${nodeId}, sin encuadrar)`;
  throw e;
}
