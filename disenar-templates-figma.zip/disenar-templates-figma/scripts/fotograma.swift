// placaN.mp4 -> fotograma como JPG. En esta maquina no hay ffmpeg; esto usa AVFoundation.
// uso: swift scripts/fotograma.swift <video> <salida.jpg> [segundo]
import AVFoundation
import AppKit

let a = CommandLine.arguments
guard a.count >= 3 else { print("uso: fotograma.swift <video> <salida.jpg> [segundo]"); exit(1) }
let seg = a.count > 3 ? Double(a[3]) ?? 1.0 : 1.0
let gen = AVAssetImageGenerator(asset: AVURLAsset(url: URL(fileURLWithPath: a[1])))
gen.appliesPreferredTrackTransform = true
gen.requestedTimeToleranceBefore = .zero
gen.requestedTimeToleranceAfter = .zero
do {
    let cg = try gen.copyCGImage(at: CMTime(seconds: seg, preferredTimescale: 600), actualTime: nil)
    guard let data = NSBitmapImageRep(cgImage: cg)
        .representation(using: .jpeg, properties: [.compressionFactor: 0.95]) else { exit(1) }
    try data.write(to: URL(fileURLWithPath: a[2]))
    print("\(a[2]) \(cg.width)x\(cg.height)")
} catch { print("error: \(error)"); exit(1) }
