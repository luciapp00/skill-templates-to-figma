#!/usr/bin/env python3
"""Lee un Google Doc de planificacion y extrae las placas y sus visuales.

Exporta el doc como HTML (export?format=html). Esa via es la mas fiable:
no necesita la API de Drive ni un navegador logueado, y a diferencia del
export en txt conserva los hrefs -- importante porque muchos visuales estan
puestos como hipervinculo sobre un texto ("Link a la carpeta") en vez de
como URL pegada a la vista.

Uso:
  doc_visuales.py <url_o_id> --listar
  doc_visuales.py <url_o_id> --fecha 3/9 [--json salida.json]
  doc_visuales.py <url_o_id> --crudo          # vuelca el texto entero

Si el parser no encuentra lo que esperabas, corre --crudo y lee el texto:
el doc lo escriben personas y el formato varia. Sacar los links a mano de
ahi es perfectamente valido.
"""

import argparse
import html
import json
import re
import sys
import urllib.parse
import urllib.request

EXPORT = "https://docs.google.com/document/d/{}/export?format=html"

# "Historias 2: Inhalar y hacer una pausa. 3/9"  |  "Carrusel 1: El Banado. 2/9"
BLOQUE = re.compile(
    r"^\s*(historias?|carrusel|carrousel|post|reel)\s*(\d+)?\s*[:\-]\s*"
    r"(.+?)\.?\s*(\d{1,2}\s*/\s*\d{1,2})\s*$",
    re.I,
)
# Quien escribe el doc no siempre usa la misma palabra: dentro de una misma
# pieza aparecen "Placa 1:", "Historia 2:" y "Historia 3" sin dos puntos. Si
# solo se reconoce "Placa" se pierden las demas, y encima en silencio.
PLACA = re.compile(
    r"^\s*(?:placas?|historias?|storys?|slides?|imagen|foto)\s*(\d+)\b", re.I
)
CAMPO_TEXTO = re.compile(r"^\s*texto\s*:\s*(.*)$", re.I)
CAMPO_VISUAL = re.compile(r"visual\s*:\s*(.*)$", re.I)
URL = re.compile(r"https?://[^\s«»|)\]]+")
DRIVE_ID = re.compile(r"/file/d/([A-Za-z0-9_-]{20,})|[?&]id=([A-Za-z0-9_-]{20,})")


def doc_id(s):
    m = re.search(r"/document/d/([A-Za-z0-9_-]+)", s)
    return m.group(1) if m else s.strip()


def fetch(did):
    req = urllib.request.Request(
        EXPORT.format(did), headers={"User-Agent": "Mozilla/5.0"}
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        sys.exit(
            f"No se pudo exportar el doc (HTTP {e.code}). Suele ser que el doc no "
            f"esta compartido por link. Pedile a quien lo escribio que lo ponga en "
            f"'cualquier persona con el enlace puede ver', o pasame el texto."
        )


def unwrap(u):
    """Google envuelve los links externos en www.google.com/url?q=<real>"""
    if "google.com/url" in u:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(u).query).get("q")
        if q:
            return q[0]
    return u


def to_text(h):
    """Aplana el HTML a texto, dejando cada href visible como << url >>."""
    h = re.sub(r"<(script|style)[^>]*>.*?</\1>", "", h, flags=re.S | re.I)

    def a(m):
        href = unwrap(html.unescape(m.group(1)))
        inner = re.sub(r"<[^>]+>", "", m.group(2))
        return f"{inner} «{href}»"

    h = re.sub(r'<a\b[^>]*href="([^"]+)"[^>]*>(.*?)</a>', a, h, flags=re.S | re.I)
    h = re.sub(r"<br[^>]*>", "\n", h, flags=re.I)
    h = re.sub(r"</(p|div|h[1-6]|tr|li)>", "\n", h, flags=re.I)
    h = re.sub(r"</t[dh]>", " | ", h, flags=re.I)
    h = re.sub(r"<[^>]+>", "", h)
    h = html.unescape(h).replace("\xa0", " ")
    h = re.sub(r"[ \t]+", " ", h)
    return re.sub(r"\n{3,}", "\n\n", h).strip()


def norm_fecha(f):
    d, m = re.split(r"\s*/\s*", f.strip())
    return f"{int(d)}/{int(m)}"


def bloques(texto):
    """Devuelve [{tipo, n, titulo, fecha, linea}] de cada bloque de desarrollo."""
    out = []
    for i, ln in enumerate(texto.split("\n")):
        m = BLOQUE.match(ln)
        if m:
            out.append(
                {
                    "tipo": m.group(1).lower().rstrip("s") or "historia",
                    "n": int(m.group(2)) if m.group(2) else None,
                    "titulo": m.group(3).strip(),
                    "fecha": norm_fecha(m.group(4)),
                    "linea": i,
                }
            )
    return out


def seccion(texto, bloque, todos):
    """Texto entre este bloque y el siguiente."""
    lineas = texto.split("\n")
    fin = len(lineas)
    for b in todos:
        if b["linea"] > bloque["linea"]:
            fin = min(fin, b["linea"])
    return lineas[bloque["linea"] : fin]


def placas(lineas):
    """Parte la seccion en placas y saca texto + visual de cada una."""
    grupos, actual = [], None
    # lineas[0] es el encabezado del bloque ("Historias 1: <titulo>. 8/9") y
    # calza con PLACA; saltearlo evita tomarlo como si fuera una placa mas.
    for ln in lineas[1:]:
        m = PLACA.match(ln)
        if m:
            actual = {"n": int(m.group(1)), "lineas": [ln]}
            grupos.append(actual)
        elif actual is not None:
            actual["lineas"].append(ln)

    res = []
    for g in grupos:
        texto_partes, visual = [], None
        capturando = False
        for ln in g["lineas"]:
            mv = CAMPO_VISUAL.search(ln)
            mt = CAMPO_TEXTO.match(ln)
            if mv:
                capturando = False
                urls = URL.findall(ln)
                # El primero gana. Si el grupo quedo mal delimitado y arrastra
                # el visual de la placa siguiente, pisar con el ultimo daria la
                # imagen equivocada sin ningun sintoma visible.
                if urls and visual is None:
                    visual = urls[0]
            elif mt:
                capturando = True
                if mt.group(1).strip():
                    texto_partes.append(mt.group(1).strip())
            elif capturando and ln.strip() and not PLACA.match(ln):
                texto_partes.append(ln.strip())
        # el visual puede haber quedado en una linea suelta posterior
        if visual is None:
            for ln in g["lineas"]:
                urls = URL.findall(ln)
                if urls:
                    visual = urls[0]
                    break

        origen, did = "otro", None
        if visual:
            m = DRIVE_ID.search(visual)
            if m:
                origen, did = "drive", (m.group(1) or m.group(2))
            elif "drive.google.com" in visual:
                origen = "drive-sin-id"
        res.append(
            {
                "placa": g["n"],
                "texto": " ".join(texto_partes).strip(),
                "visual": visual,
                "origen": origen,
                "drive_id": did,
            }
        )
    return sorted(res, key=lambda p: p["placa"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("doc")
    ap.add_argument("--fecha", help='dia del contenido, ej "3/9"')
    ap.add_argument("--listar", action="store_true")
    ap.add_argument("--crudo", action="store_true")
    ap.add_argument("--json", help="guardar el resultado en este archivo")
    a = ap.parse_args()

    texto = to_text(fetch(doc_id(a.doc)))

    if a.crudo:
        print(texto)
        return

    bs = bloques(texto)
    if not bs:
        sys.exit(
            "No encontre bloques con el patron '<Tipo> N: <titulo>. D/M'.\n"
            "Corre con --crudo y leelo a mano."
        )

    if a.listar or not a.fecha:
        print(f"{len(bs)} contenidos en el doc:\n")
        for b in bs:
            print(f"  {b['fecha']:>6}  {b['tipo']:<9} {b['titulo']}")
        if not a.fecha:
            print("\nVolve a correr con --fecha D/M para extraer uno.")
        return

    objetivo = norm_fecha(a.fecha)
    elegidos = [b for b in bs if b["fecha"] == objetivo]
    if not elegidos:
        sys.exit(
            f"No hay contenido para {objetivo}. Fechas disponibles: "
            + ", ".join(sorted({b['fecha'] for b in bs}))
        )

    salida = []
    for b in elegidos:
        ps = placas(seccion(texto, b, bs))
        salida.append({**{k: b[k] for k in ("tipo", "n", "titulo", "fecha")}, "placas": ps})

    for c in salida:
        print(f"\n{c['tipo'].upper()} {c['fecha']} - {c['titulo']}")
        print(f"{len(c['placas'])} placas\n")
        for p in c["placas"]:
            marca = "ok " if p["origen"] == "drive" else "-- "
            print(f"  {marca}placa {p['placa']}: {p['texto'][:70] or '(sin texto)'}")
            print(f"      {p['origen']}: {p['visual']}")

    pendientes = [
        p for c in salida for p in c["placas"] if p["origen"] != "drive"
    ]
    if pendientes:
        print(
            f"\n{len(pendientes)} visual(es) no son de Drive y hay que "
            f"conseguirlos aparte (ver arriba, marcados con --)."
        )

    if a.json:
        with open(a.json, "w", encoding="utf-8") as f:
            json.dump(salida, f, ensure_ascii=False, indent=2)
        print(f"\nJSON -> {a.json}")


if __name__ == "__main__":
    main()
