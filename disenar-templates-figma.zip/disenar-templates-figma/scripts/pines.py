#!/usr/bin/env python3
"""Baja pines de Pinterest al tamano original. Uso: pines.py <url> <destino.jpg> ...

El pin publico no necesita login: la meta og:image trae la URL del CDN con un
segmento de tamano (736x, 1200x) que se cambia por "originals".
"""
import re, sys, urllib.request

UA = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"}
# la meta trae content primero y property al final, con otros atributos en medio:
# hay que agarrar el tag entero y recien ahi sacarle el content.
META = re.compile(r'<meta[^>]*og:image"[^>]*>')


def get(url, timeout=60):
    return urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout).read()


def bajar(pin, destino):
    html = get(pin).decode("utf-8", "replace")
    tag = META.search(html)
    m = re.search(r'content="([^"]+)"', tag.group(0)) if tag else None
    if not m:
        return "sin og:image"
    base = m.group(1)
    candidatos = [re.sub(r"/\d+x\d*/", f"/{s}/", base) for s in ("originals", "1200x", "736x")]
    candidatos.append(base)
    for url in dict.fromkeys(candidatos):
        try:
            data = get(url)
        except Exception as e:
            continue
        if not data.startswith(b"\xff\xd8") and not data.startswith(b"\x89PNG"):
            continue
        with open(destino, "wb") as f:
            f.write(data)
        return f"{len(data)//1024} KB  {url.split('/')[3]}  {url.rsplit('/',1)[-1]}"
    return "ningun tamano respondio"


if __name__ == "__main__":
    args = sys.argv[1:]
    assert args and len(args) % 2 == 0, "pares <url> <destino>"
    for pin, destino in zip(args[::2], args[1::2]):
        print(f"{destino.rsplit('/',2)[-2]}/{destino.rsplit('/',1)[-1]}: {bajar(pin, destino)}", flush=True)
