import Vision
import CoreImage
import AppKit

let a = CommandLine.arguments
guard a.count == 3, let img = CIImage(contentsOf: URL(fileURLWithPath: a[1])) else {
    FileHandle.standardError.write("uso: recortar.swift <entrada> <salida.png>\n".data(using: .utf8)!)
    exit(1)
}
let handler = VNImageRequestHandler(ciImage: img, options: [:])
let req = VNGenerateForegroundInstanceMaskRequest()
try handler.perform([req])
guard let obs = req.results?.first else {
    FileHandle.standardError.write("Vision no encontro primer plano\n".data(using: .utf8)!)
    exit(2)
}
let buf = try obs.generateMaskedImage(ofInstances: obs.allInstances, from: handler,
                                      croppedToInstancesExtent: false)
let out = CIImage(cvPixelBuffer: buf)
try CIContext().writePNGRepresentation(of: out, to: URL(fileURLWithPath: a[2]),
                                       format: .RGBA8,
                                       colorSpace: CGColorSpace(name: CGColorSpace.sRGB)!)
print("instancias: \(obs.allInstances.count)  ->  \(a[2])")
