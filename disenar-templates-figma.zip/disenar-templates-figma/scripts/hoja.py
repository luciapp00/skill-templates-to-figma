#!/usr/bin/env python3
"""Arma una hoja de contacto con los visuales originales, para mirarlos juntos.

Una fila por carpeta, en el orden placa1, placa2, ... Las miniaturas van a su
proporcion real, sin recortar: la hoja sirve para ver que bajo y en que orden,
no para aprobar un encuadre -- el encuadre se decide despues, adentro de Figma.

Uso:
  hoja.py --salida /tmp/revision.jpg "carpeta"
  hoja.py --salida /tmp/revision.jpg "HISTORIAS/.../24-Bies" "POSTS/.../30-Madre"
"""

import argparse
import os
import re
import sys

try:
    from PIL import Image, ImageDraw
except ImportError:
    sys.exit("Falta Pillow. Instalalo con:  python3 -m pip install Pillow")

EXTS = (".jpg", ".jpeg", ".png", ".webp")
CELDA, ALTO, TITULO = 250, 330, 26


def orden(nombre):
    """Ordena placa2 antes que placa10."""
    n = re.findall(r"\d+", nombre)
    return (int(n[0]) if n else 0, nombre)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("carpetas", nargs="+")
    ap.add_argument("--salida", required=True)
    a = ap.parse_args()

    filas = []
    for c in a.carpetas:
        fs = sorted(
            (n for n in os.listdir(c) if n.lower().endswith(EXTS) and not n.startswith(".")),
            key=orden,
        )
        if not fs:
            print(f"{c}: sin imagenes, la salteo")
            continue
        filas.append((os.path.basename(c.rstrip("/")), c, fs))
    if not filas:
        sys.exit("No encontre imagenes en ninguna de las carpetas.")

    ancho = CELDA * max(len(f[2]) for f in filas) + 20
    hoja = Image.new("RGB", (ancho, (ALTO + TITULO) * len(filas) + 20), "white")
    dib = ImageDraw.Draw(hoja)
    for i, (titulo, carpeta, archivos) in enumerate(filas):
        y = 10 + i * (ALTO + TITULO)
        dib.text((10, y), titulo, fill="black")
        for j, n in enumerate(archivos):
            im = Image.open(os.path.join(carpeta, n)).convert("RGB")
            w, h = im.size
            im.thumbnail((CELDA - 20, ALTO - 14))
            hoja.paste(im, (10 + j * CELDA, y + TITULO))
            dib.text((10 + j * CELDA, y + TITULO + ALTO - 12), f"{n}  {w}x{h}", fill="gray")

    hoja.save(a.salida, quality=88)
    print(f"Hoja de contacto -> {a.salida}")


if __name__ == "__main__":
    main()
