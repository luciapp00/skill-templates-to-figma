"""Saca el fleco del fondo en el borde de un recorte con alfa.

Cada pixel del borde es una mezcla:  C = a*F + (1-a)*B,  con F el color real
del objeto y B el del fondo que quedo atras (aca, el gris del piso). Por eso el
borde se ve gris sobre un fondo de otro color. Se despeja F = (C - (1-a)*B)/a.

B no es un color unico -- cambia a lo largo del contorno -- asi que se estima
localmente: se toma el color donde el alfa es casi cero y se propaga hacia
adentro con convolucion normalizada.

El alfa NO se toca. Erosionarlo o suavizarlo se come las ramitas finas y deja
el borde festoneado; el problema es de color, no de forma.
"""
import sys
import numpy as np
from PIL import Image

src, dst = sys.argv[1], sys.argv[2]
gamma = float(sys.argv[3]) if len(sys.argv) > 3 else 1.0
im = np.asarray(Image.open(src).convert("RGBA")).astype(np.float32)
rgb, a = im[..., :3], im[..., 3:4] / 255.0


def propagar(color, peso, pasos):
    """Empuja `color` hacia donde peso==0, promediando 3x3 solo lo conocido."""
    color, peso = color * peso, peso.copy()
    for _ in range(pasos):
        pc = np.pad(color, ((1, 1), (1, 1), (0, 0)), mode="edge")
        pp = np.pad(peso, ((1, 1), (1, 1), (0, 0)), mode="edge")
        sc = sum(pc[i:i + color.shape[0], j:j + color.shape[1]] for i in range(3) for j in range(3))
        sp = sum(pp[i:i + peso.shape[0], j:j + peso.shape[1]] for i in range(3) for j in range(3))
        nuevo = peso < 0.5
        color = np.where(nuevo, sc / np.maximum(sp, 1e-6), color)
        peso = np.where(nuevo, (sp > 0).astype(np.float32), peso)
    return color


fondo = propagar(rgb, (a < 0.02).astype(np.float32), 6)   # el gris de atras
dentro = propagar(rgb, (a > 0.98).astype(np.float32), 6)  # el objeto, hacia afuera

seguro = np.maximum(a, 0.18)
limpio = np.clip((rgb - (1.0 - a) * fondo) / seguro, 0, 255)
# donde el alfa es muy bajo la division es inestable: ahi vale mas el interior
mezcla = np.clip((a - 0.10) / 0.25, 0, 1)
color = mezcla * limpio + (1 - mezcla) * dentro

# el alfa no se erosiona (festonea y se come las ramitas); se cierra con una
# curva monotona, que aprieta los medios tonos sin mover la silueta
a_fin = a ** gamma
out = np.dstack([color, a_fin * 255]).astype(np.uint8)
Image.fromarray(out).save(dst)
print(f"{src} -> {dst}  ({out.shape[1]}x{out.shape[0]}, gamma alfa {gamma})")
